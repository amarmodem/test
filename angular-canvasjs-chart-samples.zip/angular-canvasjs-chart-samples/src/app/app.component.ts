import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import * as CanvasJS from './canvasjs.min.js';
import { Chart } from 'chart.js';  
import { Title } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { Count } from '../app/count';
import {NgModule} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent implements OnInit {  
constructor(private httpClient: HttpClient) {}
url = 'http://localhost:8080/shoppingcart/count'
count: Count[];
id = [];
randomValue = [];
Linechart = [];

  ngOnInit() {
	
	

			 
		let chart = new CanvasJS.Chart("chartContainer", {
		animationEnabled: true,
		exportEnabled: true,
		title: {
			text: "Column Details"
		},
		data: [{
			type: "column",
			dataPoints: [
				{ y: 71, label: "Apple" },
				{ y: 55, label: "Mango" },
				{ y: 50, label: "Orange" },
				{ y: 65, label: "Banana" },
				{ y: 95, label: "Pineapple" },
				{ y: 68, label: "Pears" },
				{ y: 28, label: "Grapes" },
				{ y: 34, label: "Lychee" },
				{ y: 14, label: "Jackfruit" }
			]
		}]
	});
	chart.render();

	let chart3 = new CanvasJS.Chart("chartContainer3", {
		theme: "light2",
		animationEnabled: true,
		exportEnabled: true,
		title:{
			text: "Errors"
		},
		data: [{
			type: "pie",
			showInLegend: true,
			toolTipContent: "<b>{name}</b>: ${y} (#percent%)",
			indexLabel: "{name} - #percent%",
			dataPoints: [
				{ y: 450, name: "Food" },
				{ y: 120, name: "Insurance" },
				{ y: 300, name: "Traveling" },
				{ y: 800, name: "Housing" },
				{ y: 150, name: "Education" },
				{ y: 150, name: "Shopping"},
				{ y: 250, name: "Others" }
			]
		}]
	});
	chart3.render();


	let dataPoints1 = [];
	let y = 0;		
	for ( var i = 0; i < 10000; i++ ) {		  
		y += Math.round(5 + Math.random() * (-5 - 5));	
		dataPoints1.push({ y: y});
	}
	let chart2 = new CanvasJS.Chart("chartContainer2", {
		zoomEnabled: true,
		animationEnabled: true,
		exportEnabled: true,
		title: {
			text: "Performance Points"
		},
		subtitles:[{
			text: "Try Zooming and Panning"
		}],
		data: [
		{
			type: "line",                
			dataPoints: dataPoints1
		}]
	});
	chart2.render();

	let dataPoints = [];
	let dpsLength = 0;
	let chart1 = new CanvasJS.Chart("chartContainer1",{
		exportEnabled: true,
		title:{
			text:"Live Chart"
		},
		data: [{
			type: "spline",
			dataPoints : dataPoints,
		}]
	});
	
	$.getJSON("http://localhost:8080/shoppingcart/count", function(data) {  
		$.each(data, function(key, value){
			dataPoints.push({x: value.id, y: parseInt(value.randomValue)});
		});
		dpsLength = dataPoints.length;
		chart1.render();
		updateChart();
	});
	function updateChart() {	
	$.getJSON("http://localhost:8080/shoppingcart/count", function(data) {
		$.each(data, function(key, value) {
			dataPoints.push({
			x: parseInt(value.id),
			y: parseInt(value.randomValue)
			});
			dpsLength++;
		});
		
		if (dataPoints.length >  20 ) {
      		dataPoints.shift();				
      	}
		chart1.render();
		setTimeout(function(){updateChart()}, 1000);
	});
		
	
	chart1.render();


	
    }
  }
}
