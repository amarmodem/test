import { Count } from './count';

describe('Count', () => {
  it('should create an instance', () => {
    expect(new Count()).toBeTruthy();
  });
});
