import { logging } from 'protractor';

export class Count {
    id :Int32Array;
    randomValue :Int32Array;
}
