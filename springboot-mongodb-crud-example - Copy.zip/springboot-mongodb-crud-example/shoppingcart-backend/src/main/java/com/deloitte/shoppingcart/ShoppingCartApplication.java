package com.deloitte.shoppingcart;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import com.deloitte.shoppingcart.model.CartItem;
import com.deloitte.shoppingcart.model.CartPricing;
import com.deloitte.shoppingcart.model.Order;
import com.deloitte.shoppingcart.model.Product;
import com.deloitte.shoppingcart.model.User;
import com.deloitte.shoppingcart.repository.OrderRepository;
import com.deloitte.shoppingcart.repository.ProductRepository;
import com.deloitte.shoppingcart.repository.UserRepository;

@SpringBootApplication
public class ShoppingCartApplication {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private OrderRepository orderRepository;

	public static void main(String[] args) {
		SpringApplication.run(ShoppingCartApplication.class, args);
	}

	
	@Bean
	public CommandLineRunner commandLineRunner(ApplicationContext ctx) {
		return args -> {

			orderRepository
					.save(new Order("amar@de", "2/21/2020", "", "Inprogress", loadCartItems(), loadCartPricing()));
			orderRepository
					.save(new Order("amar@de2", "2/21/2020", "", "Inprogress", loadCartItems(), loadCartPricing()));
			
			
			userRepository.save(new	User("GOPI","Gopi@123",9876543210L,"Deloitte Default T1","Deloitte Shipping T1"));
			userRepository.save(new User("G2","Gop2@123",9576543210L,"Deloitte Default T2","Deloitte Shipping T2"));

			
			// productId, String productName, String brand, String size, String color,
			// String gender,
			// String imageUrl, int price, int stock

			productRepository.save(new Product("GDN-0011", "Green Shirt Men", "WROGN", "S,M,L,XL", "Green", "M",
					"http://openclipart.org/image/300px/svg_to_png/26215/Anonymous_Leaf_Rake.png", 1200, 5));

			productRepository.save(new Product("GDN-0012", "White Shirt Men", "ARROW", "S,M,L,XL", "White", "M",
					"http://openclipart.org/image/300px/svg_to_png/26215/Anonymous_Leaf_Rake.png", 1540, 5));

			productRepository.save(new Product("GDN-0013", "TOP", "SOCH", "S,M,L,XL", "Yellow", "F",
					"http://openclipart.org/image/300px/svg_to_png/26215/Anonymous_Leaf_Rake.png", 1400, 5));

			productRepository.save(new Product("GDN-0014", "Kurtha", "BIBA", "S,M,L,XL", "Black", "F",
					"http://openclipart.org/image/300px/svg_to_png/26215/Anonymous_Leaf_Rake.png", 1200, 5));

			productRepository.save(new Product("GDN-0015", "Red Shirt Men", "MUFTI", "S,M,L,XL", "Red", "M",
					"http://openclipart.org/image/300px/svg_to_png/26215/Anonymous_Leaf_Rake.png", 140, 5));

			System.out.println();
			System.out.println("Users found with findAll():");
			System.out.println("-------------------------------");
			for (User user : userRepository.findAll()) {
				System.out.println(user);
			}
			System.out.println();

			System.out.println("Products found with findAll():");
			System.out.println("-------------------------------");
			for (Product product : productRepository.findAll()) {
				System.out.println(product);
			}
			System.out.println();

			System.out.println("Order found with findAll():");
			System.out.println("-------------------------------");
			for (Order order : orderRepository.findAll()) {
				System.out.println(order.getEmailId());
			}
			System.out.println();

		};

	} 

	private List<CartItem> loadCartItems() {

		List<CartItem> cartItems = new ArrayList<CartItem>();
		CartItem cartItem1 = new CartItem();
		CartItem cartItem2 = new CartItem();

		cartItem1.setPrice(100);
		cartItem1.setProductId("ABZB");
		cartItem1.setSize("M");
		cartItem1.setUnits(5);

		cartItem2.setPrice(10);
		cartItem2.setProductId("ANCB");
		cartItem2.setSize("L");
		cartItem2.setUnits(1);

		cartItems.add(cartItem1);
		cartItems.add(cartItem2);

		return cartItems;
	}

	private CartPricing loadCartPricing() {

		CartPricing cartPricing = new CartPricing();

		cartPricing.setBagDiscount(10);
		cartPricing.setBagTotal(20);
		cartPricing.setCouponDiscount(10);
		cartPricing.setDeliveryCharges(0);
		cartPricing.setDiscountedTotal(5);
		cartPricing.setTax(12);
		cartPricing.setTotalCharges(210);

		return cartPricing;
	}
}
