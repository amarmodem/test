package com.deloitte.shoppingcart.test;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
