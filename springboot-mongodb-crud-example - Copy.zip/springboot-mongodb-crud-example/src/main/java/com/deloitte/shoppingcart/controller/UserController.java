package com.deloitte.shoppingcart.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.shoppingcart.exception.ResourceNotFoundException;
import com.deloitte.shoppingcart.model.User;
import com.deloitte.shoppingcart.repository.UserRepository;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/shoppingcart")
public class UserController {

	private final UserRepository userRepository;
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserController(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@GetMapping("/users")
	public List<User> getUsers() {
		logger.debug("---Getting all users---");
		return this.userRepository.findAll();
	}

	@GetMapping("/login/{emailId}")
	public ResponseEntity<User> getUserByEmailId(@PathVariable String emailId) throws ResourceNotFoundException {
		User user = userRepository.findByEmailId(emailId);
		if (user != null) {
			return new ResponseEntity<User>(user, HttpStatus.OK);
		} else {
			throw new ResourceNotFoundException("User not found for this emailId :: " + emailId);
		}
	}

	@PostMapping("/signup")
	public ResponseEntity<?> login(@Valid @RequestBody User user) throws ResourceNotFoundException {

		User dbUser = userRepository.findByEmailId(user.getEmailId());
		if (null != dbUser) {
			throw new ResourceNotFoundException("User already registered found withi emailId :: " + user.getEmailId());

		} else {
			userRepository.save(user);
			return new ResponseEntity<User>(user, HttpStatus.OK);
		}
	}

	@PutMapping("/updateUserDetails")
	public ResponseEntity<?> updateLoginDetails(@Valid @RequestBody User user) throws ResourceNotFoundException {

		User dbUser = userRepository.findByEmailId(user.getEmailId());

		if (null != dbUser) {

			if (null != user.getDefaultBillingAddress()) {
				dbUser.setDefaultBillingAddress(user.getDefaultBillingAddress());
			}
			if (null != user.getDefaultShippingAddress()) {
				dbUser.setDefaultShippingAddress(user.getDefaultShippingAddress());
			}
			userRepository.save(dbUser);
			return new ResponseEntity<User>(user, HttpStatus.OK);
		} else {
			throw new ResourceNotFoundException("User not found for this id :: " + user.getEmailId());
		}
	}

}
