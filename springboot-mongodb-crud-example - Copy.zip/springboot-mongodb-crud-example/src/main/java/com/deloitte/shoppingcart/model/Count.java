package com.deloitte.shoppingcart.model;

public class Count {

	private long id;
	private long randomValue;
	
	

	public Count() {
	}
	

	public Count(int id,Long randomValue) {
		this.randomValue=randomValue;
		this.id=id;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getRandomValue() {
		return randomValue;
	}
	public void setRandomValue(long randomValue) {
		this.randomValue = randomValue;
	}
	
	
	
}
