package com.deloitte.shoppingcart.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.deloitte.shoppingcart.model.Count;

public interface CountRepository extends MongoRepository<Count, Long> {
	
	public List<Count> findAll();

}
